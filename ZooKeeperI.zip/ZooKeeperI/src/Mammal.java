
public class Mammal {
	Integer energy;
	
	public Mammal() {
		this.energy = 100;
	}
	
    public void showEnergy(){
        System.out.println("Energy level: " + this.energy);       
    }
}
