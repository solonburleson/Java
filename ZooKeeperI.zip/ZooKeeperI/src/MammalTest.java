
public class MammalTest {

	public static void main(String[] args) {
		Gorilla joe = new Gorilla();
        joe.throwSomething();
        joe.showEnergy();
        joe.throwSomething();
        joe.showEnergy();
        joe.throwSomething();
        joe.showEnergy();
        joe.eatBananas();
        joe.showEnergy();
        joe.eatBananas();
        joe.showEnergy();
        joe.climb();
        joe.showEnergy();

	}

}
